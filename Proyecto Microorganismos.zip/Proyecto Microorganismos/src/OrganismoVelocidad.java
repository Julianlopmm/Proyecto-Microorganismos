public class OrganismoVelocidad extends OrganismoBasico{
    
    public OrganismoVelocidad(int energia, int vision,int velocidad, int edad){
        super(energia, vision, velocidad, edad);
    }
}
