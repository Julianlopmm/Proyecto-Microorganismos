public class OrganismoVision extends OrganismoBasico{
    
    public OrganismoVision (int energia, int vision,int velocidad, int edad){
        super(energia, vision, velocidad, edad);
    }
}
